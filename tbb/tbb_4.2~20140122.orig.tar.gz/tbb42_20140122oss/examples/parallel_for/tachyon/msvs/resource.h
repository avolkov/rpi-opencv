#define IDC_MYICON                      2
#define IDD_GUI    			102
#define IDS_APP_TITLE                   103
#define IDI_GUI           		107
#define IDI_SMALL                       108
#define IDC_GUI           		109
#define IDR_MAINFRAME                   128
#define IDC_STATIC                      -1
